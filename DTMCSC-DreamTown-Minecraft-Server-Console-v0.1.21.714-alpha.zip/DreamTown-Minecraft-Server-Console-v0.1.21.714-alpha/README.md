# 幻梦之乡MC服务器控制台-DTMCSC-DreamTown Minecraft Server Console

#### 介绍
- 幻梦之乡MC服务器控制台（DreamTown Minecraft Server Console，简称DTMCSC）
- 基于MCSGUI源码重新开发(该程序发布地址：https://www.mcbbs.net/thread-300368-1-1.html)
- 非完全原创，非任何软件(特别包括MCSGUI)后续版本
- 在原软件开源基础上进行参考于二次开发

#### 软件架构
基于x86平台，C#语言编写，需要.NET支持

#### 安装教程
开箱即用！非常方便有木有！

#### 使用说明
1.  xxxx
2.  xxxx
3.  xxxx

#### 参与贡献
1.  @Liten_PanJun首席开发
2.  感谢@pppploi8的MCSGUI源代码作为基础