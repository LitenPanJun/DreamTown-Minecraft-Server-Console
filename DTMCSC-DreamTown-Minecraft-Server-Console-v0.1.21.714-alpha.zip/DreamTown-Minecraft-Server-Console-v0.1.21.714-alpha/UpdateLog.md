# 幻梦之乡MC服务器控制台-DTMCSC-DreamTown Minecraft Server Console更新日志

#### 2021.7.12-v0.1.21.712-alpha
- 完成基本UI设计，未实装功能，将在v0.2实装

#### 2021.7.14-v0.2.21.714-alpha
- 完成基本功能实装
- 未实装功能在尝试使用时会弹窗提醒
- 开服主功能仍在完善，目前仍为alpha版，无法使用

#### YYYY.MM.DD-vX.X.XX.XXXX
- XXXXX